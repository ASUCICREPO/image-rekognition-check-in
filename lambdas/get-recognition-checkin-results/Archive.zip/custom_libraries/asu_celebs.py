def find_asu_vip(asurite):

    if(asurite == 'larry_scott_pac'):
        info = {'response': {'docs': [
            {'asuriteId': 'larry_scott_pac',
             'firstName': 'Larry',
             'middleName': '',
             'lastName': 'Scott',
             'displayName': 'Larry Scott',
             'workingTitle': 'Commissioner - PAC 12',
             'primaryDepartment': 'PAC 12',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'teresa_carlson_aws'):
        info = {'response': {'docs': [
            {'asuriteId': 'teresa_carlson_aws',
             'firstName': 'Teresa',
             'middleName': '',
             'lastName': 'Carlson',
             'displayName': 'Teresa Carlson',
             'workingTitle': 'Vice President, Worldwide Public Sector at Amazon',
             'primaryDepartment': 'Amazon',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'anjalisrivastava'):
        info = {'response': {'docs': [
            {'asuriteId': 'anjalisrivastava',
             'firstName': 'Anjali',
             'middleName': '',
             'lastName': 'Srivastava',
             'displayName': 'Anjali Srivastava',
             'workingTitle': 'Cloud Developer Associate',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    
    elif(asurite == 'ArunArunachalam'):
        info = {'response': {'docs': [
            {'asuriteId': 'ArunArunachalam',
             'firstName': 'Arun',
             'middleName': '',
             'lastName': 'Arunachalam',
             'displayName': 'Arun Arunachalam',
             'workingTitle': 'Senior Solutions Architect, AWS',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'ColleenSchwab'):
        info = {'response': {'docs': [
            {'asuriteId': 'ColleenSchwab',
             'firstName': 'Colleen',
             'middleName': '',
             'lastName': 'Schwab',
             'displayName': 'Colleen Schwab',
             'workingTitle': 'Digital Innovation Lead, AWS',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'JohnRome'):
        info = {'response': {'docs': [
            {'asuriteId': 'JohnRome',
             'firstName': 'John',
             'middleName': '',
             'lastName': 'Rome',
             'displayName': 'John Rome',
             'workingTitle': 'Deputy CIO & Strategic Partnerships, ASU',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'RyanHendrix'):
        info = {'response': {'docs': [
            {'asuriteId': 'RyanHendrix',
             'firstName': 'Ryan',
             'middleName': '',
             'lastName': 'Hendrix',
             'displayName': 'Ryan Hendrix',
             'workingTitle': 'General Manager, ASU',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'TomOrr'):
        info = {'response': {'docs': [
            {'asuriteId': 'TomOrr',
             'firstName': 'Tom',
             'middleName': '',
             'lastName': 'Orr',
             'displayName': 'Tom Orr',
             'workingTitle': 'Senior Program Manager, AWS',
             'primaryDepartment': 'ASU CIC',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'doug_governer'):
        info = {'response': {'docs': [
            {'asuriteId': 'doug_governer',
             'firstName': 'Doug',
             'middleName': '',
             'lastName': 'Ducey',
             'displayName': 'Doug Ducey',
             'workingTitle': 'Governer',
             'primaryDepartment': 'State of Arizona',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'comacho_gpec'):
        info = {'response': {'docs': [
            {'asuriteId': 'comacho_gpec',
             'firstName': 'Chris',
             'middleName': '',
             'lastName': 'Comacho',
             'displayName': 'Chris Comacho',
             'workingTitle': 'President and CEO',
             'primaryDepartment': 'Greater Phoenix Economic Council',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'jim_lane_mayor'):
        info = {'response': {'docs': [
            {'asuriteId': 'jim_lane_mayor',
             'firstName': 'Jim',
             'middleName': '',
             'lastName': 'Lane',
             'displayName': 'Jim Lane',
             'workingTitle': 'Mayor',
             'primaryDepartment': 'Scottsdale',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'mark_mitchell_mayor_tempe'):
        info = {'response': {'docs': [
            {'asuriteId': 'mark_mitchell_mayor_tempe',
             'firstName': 'Mark',
             'middleName': '',
             'lastName': 'Mitchell',
             'displayName': 'Mark Mitchell',
             'workingTitle': 'Mayor',
             'primaryDepartment': 'City of Tempe',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'thelda_mayor_phx'):
        info = {'response': {'docs': [
            {'asuriteId': 'thelda_mayor_phx',
             'firstName': 'Thelda',
             'middleName': '',
             'lastName': 'Williams',
             'displayName': 'Thelda Williams',
             'workingTitle': 'Mayor',
             'primaryDepartment': 'City of Phoenix',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'wolkove_mgmt_arc_az'):
        info = {'response': {'docs': [
            {'asuriteId': 'wolkove_mgmt_arc_az',
             'firstName': 'Jeff',
             'middleName': '',
             'lastName': 'Wolkove',
             'displayName': 'Jeff Wolkove',
             'workingTitle': 'State Data Management Architect',
             'primaryDepartment': 'Arizona',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'jurasin_cal_poly'):
        info = {'response': {'docs': [
            {'asuriteId': 'jurasin_cal_poly',
             'firstName': 'Paul',
             'middleName': '',
             'lastName': 'Jurasin',
             'displayName': 'Paul Jurasin',
             'workingTitle': 'Director of New Programs for ITS',
             'primaryDepartment': '',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    elif(asurite == 'merihew_aws'):
        info = {'response': {'docs': [
            {'asuriteId': 'merihew_aws',
             'firstName': 'Ann',
             'middleName': '',
             'lastName': 'Merihew',
             'displayName': 'Ann Merihew',
             'workingTitle': 'Director, AWS',
             'primaryDepartment': '',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'butler_aws'):
        info = {'response': {'docs': [
            {'asuriteId': 'butler_aws',
             'firstName': 'Ben',
             'middleName': '',
             'lastName': 'Butler',
             'displayName': 'Ben Butler',
             'workingTitle': 'AWS Global Head, CICs',
             'primaryDepartment': '',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'reiter_asu'):
        info = {'response': {'docs': [
            {'asuriteId': 'reiter_asu',
             'firstName': 'Duke',
             'middleName': '',
             'lastName': 'Reiter',
             'displayName': 'Duke Reiter',
             'workingTitle': 'Special Advisor to President',
             'primaryDepartment': '',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'alika_kumar'):
        info = {'response': {'docs': [
            {'asuriteId': 'alika_kumar',
             'firstName': 'Alika',
             'middleName': '',
             'lastName': 'Kumar',
             'displayName': 'Alika Kumar',
             'workingTitle': 'Executive Director',
             'primaryDepartment': 'Phoenix MBDA Business Center',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'scoville_weaver'):
        info = {'response': {'docs': [
            {'asuriteId': 'scoville_weaver',
             'firstName': 'Amy',
             'middleName': '',
             'lastName': 'Scoville-Weaver',
             'displayName': 'Amy Scoville-Weaver',
             'workingTitle': 'Program Manager',
             'primaryDepartment': 'Arizona State University',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'bin_jones_cox'):
        info = {'response': {'docs': [
            {'asuriteId': 'bin_jones_cox',
             'firstName': 'Bin',
             'middleName': '',
             'lastName': 'Jones',
             'displayName': 'Bin Jones',
             'workingTitle': 'Sales Engineering Manager',
             'primaryDepartment': 'COX Business',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'valenzuela_peoria'):
        info = {'response': {'docs': [
            {'asuriteId': 'valenzuela_peoria',
             'firstName': 'David',
             'middleName': '',
             'lastName': 'Valenzuela',
             'displayName': 'David Valenzuela',
             'workingTitle': 'Chief Business Attraction Officer',
             'primaryDepartment': 'City of Peoria',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'brian_kearney'):
        info = {'response': {'docs': [
            {'asuriteId': 'brian_kearney',
             'firstName': 'Brian',
             'middleName': '',
             'lastName': 'Kearney',
             'displayName': 'Brian Kearney',
             'workingTitle': 'First Vice President',
             'primaryDepartment': 'Catellus Development Corporation',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'eric_redman_parsons'):
        info = {'response': {'docs': [
            {'asuriteId': 'eric_redman_parsons',
             'firstName': 'Eric',
             'middleName': '',
             'lastName': 'Redman',
             'displayName': 'Eric Redman',
             'workingTitle': 'VP, Systems',
             'primaryDepartment': 'Parsons',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'sloan_arizona'):
        info = {'response': {'docs': [
            {'asuriteId': 'sloan_arizona',
             'firstName': 'J R',
             'middleName': '',
             'lastName': 'Sloan',
             'displayName': 'J R Sloan',
             'workingTitle': 'CTO and Deputy State CIO',
             'primaryDepartment': 'State of Arizona',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'mirasola_centurylink'):
        info = {'response': {'docs': [
            {'asuriteId': 'mirasola_centurylink',
             'firstName': 'Jeff',
             'middleName': '',
             'lastName': 'Mirasola',
             'displayName': 'Jeff Mirasola',
             'workingTitle': 'Director State and Local Government Affairs',
             'primaryDepartment': 'CenturyLink',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'joe_hitt_gox'):
        info = {'response': {'docs': [
            {'asuriteId': 'joe_hitt_gox',
             'firstName': 'Joe',
             'middleName': '',
             'lastName': 'Hitt',
             'displayName': 'Joe Hitt',
             'workingTitle': 'CEO and Executive Director',
             'primaryDepartment': 'Gox Studio and Wearable Robotics Association',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'kasiah_kluger'):
        info = {'response': {'docs': [
            {'asuriteId': 'kasiah_kluger',
             'firstName': 'Kasiah',
             'middleName': '',
             'lastName': 'Kluger',
             'displayName': 'Kasiah Kluger',
             'workingTitle': 'VP of Operations and Business Development',
             'primaryDepartment': 'Arizona Israel Technology Alliance',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'kenja_hassan'):
        info = {'response': {'docs': [
            {'asuriteId': 'kenja_hassan',
             'firstName': 'Kenja',
             'middleName': '',
             'lastName': 'Hassan',
             'displayName': 'Kenja Hassan',
             'workingTitle': 'Director',
             'primaryDepartment': 'Government and Community Engagement',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'kevin_kappler'):
        info = {'response': {'docs': [
            {'asuriteId': 'kevin_kappler',
             'firstName': 'Kevin',
             'middleName': '',
             'lastName': 'Kappler',
             'displayName': 'Kevin Kappler',
             'workingTitle': 'Director',
             'primaryDepartment': 'Enterprise Sales, COX',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'leslie_gahagan'):
        info = {'response': {'docs': [
            {'asuriteId': 'leslie_gahagan',
             'firstName': 'Leslie',
             'middleName': '',
             'lastName': 'Gahangan',
             'displayName': 'Leslie Gahagan',
             'workingTitle': 'Director, Emerging Technologies',
             'primaryDepartment': 'Greater Phoenix Economic Council',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'matthew_arvay'):
        info = {'response': {'docs': [
            {'asuriteId': 'matthew_arvay',
             'firstName': 'Matthew',
             'middleName': '',
             'lastName': 'Arvay',
             'displayName': 'Matthew Arvay',
             'workingTitle': 'Chief Information Officer',
             'primaryDepartment': 'City of Phoenix',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'peter_costa'):
        info = {'response': {'docs': [
            {'asuriteId': 'peter_costa',
             'firstName': 'Peter',
             'middleName': '',
             'lastName': 'Costa',
             'displayName': 'Peter Costa',
             'workingTitle': 'CEO',
             'primaryDepartment': 'Baltu Studios',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'rosa_inchausti'):
        info = {'response': {'docs': [
            {'asuriteId': 'rosa_inchausti',
             'firstName': 'Rosa',
             'middleName': '',
             'lastName': 'Inchuasti',
             'displayName': 'Rosa Inchuasti',
             'workingTitle': 'Director of Strategic Management and Diversity',
             'primaryDepartment': 'City of Tempe',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'sandra_watson'):
        info = {'response': {'docs': [
            {'asuriteId': 'sandra_watson',
             'firstName': 'Sandra',
             'middleName': '',
             'lastName': 'Watson',
             'displayName': 'Sandra Watson',
             'workingTitle': 'President and CEO',
             'primaryDepartment': 'Arizona Commerce Authority',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'sharon_harper'):
        info = {'response': {'docs': [
            {'asuriteId': 'sharon_harper',
             'firstName': 'Sharon',
             'middleName': '',
             'lastName': 'Harper',
             'displayName': 'Sharon Harper',
             'workingTitle': 'President and CEO',
             'primaryDepartment': 'The Plaza Company',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'stephane_frijia'):
        info = {'response': {'docs': [
            {'asuriteId': 'stephane_frijia',
             'firstName': 'Stephane',
             'middleName': '',
             'lastName': 'Frijia',
             'displayName': 'Stephane Frijia',
             'workingTitle': 'Senior Vice President',
             'primaryDepartment': 'Greater Phoenix Economic Council',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'todd_hardy'):
        info = {'response': {'docs': [
            {'asuriteId': 'todd_hardy',
             'firstName': 'Todd',
             'middleName': '',
             'lastName': 'Hardy',
             'displayName': 'Todd Hardy',
             'workingTitle': 'Managing Director',
             'primaryDepartment': 'KED, Innovations Zones',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'vik_patel'):
        info = {'response': {'docs': [
            {'asuriteId': 'vik_patel',
             'firstName': 'Vik',
             'middleName': '',
             'lastName': 'Patel',
             'displayName': 'Vik Patel',
             'workingTitle': 'CEO',
             'primaryDepartment': 'Datasoft Corp',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}

    elif(asurite == 'vladimir_livshits'):
        info = {'response': {'docs': [
            {'asuriteId': 'vladimir_livshits',
             'firstName': 'Vladimir',
             'middleName': '',
             'lastName': 'Livshits',
             'displayName': 'Vladimir Livshits',
             'workingTitle': 'Director of Transportaion Technologies and Services',
             'primaryDepartment': 'MAG',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
        
    elif(asurite == 'cvasily'):
        info = {'response': {'docs': [
            {'asuriteId': 'cvasily',
             'firstName': 'Christine',
             'middleName': '',
             'lastName': 'Vasily',
             'displayName': 'Christine Vasily',
             'workingTitle': '',
             'primaryDepartment': '',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
        
    elif(asurite == 'dquangvinh'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'dquangvinh',
             'firstName' : 'Doan',
             'middleName' : '',
             'lastName' : 'Quang Vinh',
             'displayName' : 'Dr. Doan Quang Vinh',
             'workingTitle': 'Rector',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    
    elif(asurite == 'dvandung'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'dvandung',
             'firstName' : 'Do',
             'middleName' : '',
             'lastName' : 'Van Dung',
             'displayName' : 'Dr. Do Van Dung',
             'workingTitle': 'Rector',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'ltancuong'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'ltancuong',
             'firstName' : 'Le',
             'middleName' : '',
             'lastName' : 'Tan Cuong',
             'displayName' : 'Le Tan Cuong',
             'workingTitle': 'Deputy Head of Office of Science, Technology, and International Affairs',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
        
    elif(asurite == 'ntandzung'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'ntandzung',
             'firstName' : 'Nguyen',
             'middleName' : '',
             'lastName' : 'Tan Dzung',
             'displayName' : 'Dr. Nguyen Tan Dzung',
             'workingTitle': 'Vice Dean of Chemical and Food Technology',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'nvanlonggiang'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'nvanlonggiang',
             'firstName' : 'Nguyen',
             'middleName' : '',
             'lastName' : 'Van Long Giang',
             'displayName' : 'Dr. Nguyen Van Long Giang',
             'workingTitle': 'Vice Dean of High Quality Training',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'vtrongluat'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'vtrongluat',
             'firstName' : 'Vu',
             'middleName' : '',
             'lastName' : 'Trong Luat',
             'displayName' : 'Vu Trong Luat',
             'workingTitle': 'Director of Library',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'dthanhngan'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'dthanhngan',
             'firstName' : 'Dinh',
             'middleName' : '',
             'lastName' : 'Thanh Ngan',
             'displayName' : 'Dinh Thanh Ngan',
             'workingTitle': 'Head of Quality Assurance Office',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'mthanhphong'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'mthanhphong',
             'firstName' : 'Mai',
             'middleName' : '',
             'lastName' : 'Thanh Phong',
             'displayName' : 'Dr. Mai Thanh Phong',
             'workingTitle': 'Rector',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'ndanhthao'):
        info = {'response' : {'docs': [
            {'asuriteId' : 'ndanhthao',
             'firstName' : 'Nguyen',
             'middleName' : '',
             'lastName' : 'Danh Thao',
             'displayName' : 'Dr. Nguyen Danh Thao',
             'workingTitle': 'Vice Rector',
             'primaryDepartment' :'',
             'primaryEmplClass': '',
             'locations' : 'United States'
            }
        ] }}
    elif(asurite == 'derek_staahl_reporter'):
        info = {'response': {'docs': [
            {'asuriteId': 'derek_staahl_reporter',
             'firstName': 'Derek',
             'middleName': '',
             'lastName': 'Staahl',
             'displayName': 'Derek Staahl',
             'workingTitle': 'Anchor',
             'primaryDepartment': '3 TV and CBS',
             'primaryEmplClass': '',
             'locations': 'United States'
             }
        ]}}
    else:
        info = None
    return info
